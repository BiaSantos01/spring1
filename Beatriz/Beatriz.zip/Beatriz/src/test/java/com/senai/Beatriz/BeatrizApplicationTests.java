package com.senai.Beatriz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeatrizApplicationTests {

	@Test
	void contextLoads() {
	}

}
