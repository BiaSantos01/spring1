package com.senai.Beatriz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeatrizApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeatrizApplication.class, args);
	}

}
